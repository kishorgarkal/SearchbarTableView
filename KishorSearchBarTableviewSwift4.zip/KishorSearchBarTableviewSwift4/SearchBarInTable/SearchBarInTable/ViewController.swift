//
//  ViewController.swift
//  SearchBarInTable
//
//  Created by Kishor Garkal on 14/11/17.
//  Copyright © 2017 Kishor Garkal. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    @IBOutlet var table: UITableView!
    @IBOutlet var searchBar: UISearchBar!
    
    var EmployeeArray = [Emp]()
    var currentEmployeeArray = [Emp]() //update table
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpEmployees()
        setUpSearchBar()
        alterLayout()
    }
    
    private func setUpEmployees() {
        // CATS
        EmployeeArray.append(Emp(name: "Amber", category: .CEO, image:"1"))
        EmployeeArray.append(Emp(name: "James", category: .Developer, image:"2"))
        EmployeeArray.append(Emp(name: "Peter", category: .CEO, image:"3"))
        // DOGS
        EmployeeArray.append(Emp(name: "Haywood", category: .Manager, image:"4"))
        EmployeeArray.append(Emp(name: "Shell", category: .Developer, image:"5"))
        EmployeeArray.append(Emp(name: "James", category: .Manager, image:"6"))
        
        EmployeeArray.append(Emp(name: "Akshay", category: .CEO, image:"Akshay"))
        EmployeeArray.append(Emp(name: "bipasha", category: .Developer, image:"bipasha"))
        EmployeeArray.append(Emp(name: "deepika", category: .CEO, image:"deepika"))
        // DOGS
        EmployeeArray.append(Emp(name: "Hritik", category: .Manager, image:"Hritik"))
        EmployeeArray.append(Emp(name: "Ranvir", category: .Developer, image:"Ranvir"))
        EmployeeArray.append(Emp(name: "Shahrukh", category: .Manager, image:"Shahrukh"))
        EmployeeArray.append(Emp(name: "Varun", category: .Developer, image:"Varun"))
        currentEmployeeArray = EmployeeArray
    }
    
    private func setUpSearchBar() {
        searchBar.delegate = self
    }
    
    func alterLayout() {
        table.tableHeaderView = UIView()
        // search bar in section header
        table.estimatedSectionHeaderHeight = 50
        // search bar in navigation bar
        //navigationItem.leftBarButtonItem = UIBarButtonItem(customView: searchBar)
        navigationItem.titleView = searchBar
        searchBar.showsScopeBar = false // you can show/hide this dependant on your layout
        searchBar.placeholder = "Search Employee by Name"
    }
        
    // Table
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currentEmployeeArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? TableCell else {
            return UITableViewCell()
        }
        cell.nameLbl.text = currentEmployeeArray[indexPath.row].name
        cell.DesignationLbl.text = currentEmployeeArray[indexPath.row].category.rawValue
        cell.imgView.image = UIImage(named:currentEmployeeArray[indexPath.row].image)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    // This two functions can be used if you want to show the search bar in the section header
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        return searchBar
//    }
    
//    // search bar in section header
//    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
//        return UITableViewAutomaticDimension
//    }
    
    // Search Bar
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        currentEmployeeArray = EmployeeArray.filter({ animal -> Bool in
            switch searchBar.selectedScopeButtonIndex {
            case 0:
                if searchText.isEmpty { return true }
                return animal.name.lowercased().contains(searchText.lowercased())
            case 1:
                if searchText.isEmpty { return animal.category == .Manager }
                return animal.name.lowercased().contains(searchText.lowercased()) &&
                animal.category == .Manager
            case 2:
                if searchText.isEmpty { return animal.category == .CEO }
                return animal.name.lowercased().contains(searchText.lowercased()) &&
                animal.category == .CEO
            case 3:
                if searchText.isEmpty { return animal.category == .CEO }
                return animal.name.lowercased().contains(searchText.lowercased()) &&
                    animal.category == .Developer
            default:
                return false
            }
        })
        table.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        switch selectedScope {
        case 0:
            currentEmployeeArray = EmployeeArray
        case 1:
            currentEmployeeArray = EmployeeArray.filter({ animal -> Bool in
                animal.category == EmployeeType.Manager
            })
        case 2:
            currentEmployeeArray = EmployeeArray.filter({ animal -> Bool in
                animal.category == EmployeeType.CEO
            })
        case 3:
            currentEmployeeArray = EmployeeArray.filter({ animal -> Bool in
                animal.category == EmployeeType.Developer
            })
        default:
            break
        }
        table.reloadData()
    }
}

class Emp {
    let name: String
    let image: String
    let category: EmployeeType
    
    init(name: String, category: EmployeeType, image: String) {
        self.name = name
        self.category = category
        self.image = image
    }
}

enum EmployeeType: String {
    case CEO = "CEO"
    case Manager = "Manager"
    case Developer = "Developer"
    
}


