# iOS-Swift4-SearchBar-TableView-iPhoneX

Hi iOS Developers!!!

This time, I am talking about the UISearchBar in TableView in Swift 4 in Xcode 9 featuring the design of iOS 11 and iPhone X.

I not only included the details to implement the search bar but also shows you guys few options to place the search, which will give your app users quite different user experience.

The full video tutorial is here in Youtube:
https://youtu.be/4RyhnwIRjpA

Also follow my social account: 
Facebook: https://www.facebook.com/iosetutorial/
Twitter: https://twitter.com/sheldonwaaaaang 
Github: https://github.com/SheldonWangRJT

To donate to me, please use the following Paypal link:
https://www.paypal.com/us/cgi-bin/webscr?cmd=_flow&SESSION=3OPurxdLYJ5hDnhk2VwCG5IH3l3XkWA--xie554lWzKQKSSDIBXro5lf5v0&dispatch=5885d80a13c0db1f8e263663d3faee8d83a0bf7db316a7beb1b14b43acd04037&rapidsState=Donation__DonationFlow___StateDonationBilling&rapidsStateSignature=66e8cff0a1882cb53b44813529696734ec6f78f4
